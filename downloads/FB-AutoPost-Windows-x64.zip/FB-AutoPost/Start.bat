@echo off
cd /d "%~dp0app"
"..\runtime\python.exe" main.py
pause
